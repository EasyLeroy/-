<?php
//取文件信息

$arr = $_FILES["file"];
$name = $_POST['name'];
$num = $_POST['num'];
$banji = $_POST['banji'];
$qq = $_POST['qq'];
$phone = $_POST['phone'];
$team = $_POST['team'];


@mysql_connect('localhost','root','');
  mysql_query('set names utf8');
  mysql_select_db('yiban'); //数据库名


  $sql="insert into {$team} (姓名,学号,QQ,联系方式,班级) values('{$name}','{$num}','{$qq}','{$phone}','{$banji}')";
  //var_dump ($sql);
  $res = mysql_query($sql);


//var_dump($arr);
//加限制条件
//1.文件类型
//2.文件大小
//3.保存的文件名不重复
if(/*($arr["type"]=="image/jpeg" || $arr["type"]=="image/png" ) && */$arr["size"]<10241000 )
{
//临时文件的路径
$arr["tmp_name"];


  @$huozhui = array_pop(explode('.',$arr["name"]));

//上传的文件存放的位置
//避免文件重复: 
//1.加时间戳.time()加用户名.$uid或者加.date('YmdHis')
//2.类似网盘，使用文件夹来防止重复
$filename = "./article/".$team."/".$num."_".date('YmdHis').".".$huozhui;

//保存之前判断该文件是否存在
  if(file_exists($filename))
  {
    echo "该文件已存在";
  }
  else
  {
  //中文名的文件出现问题，所以需要转换编码格式
  $filename = iconv("UTF-8","gb2312",$filename);
  //移动临时文件到上传的文件存放的位置（核心代码）
  //括号里：1.临时文件的路径, 2.存放的路径
  move_uploaded_file($arr["tmp_name"],$filename);
  }
}
else
{
  echo "上传的文件大小或类型不符";
}

?>
<script>
alert("上传成功！");
window.location.href="./xuanze.php"; 

</script>

