<?php




/*
**获取当年目录下所有的文件夹名
*/
$handler = opendir('article');
$name = array();

/*其中$filename = readdir($handler)

每次循环时将读取的文件名赋值给$filename，$filename !== false。

一定要用!==，因为如果某个文件名如果叫'0′，或某些被系统认为是代表false，用!=就会停止循环

*/

while( ($filename = readdir($handler)) !== false ) 
{

 //略过linux目录的名字为'.'和‘..'的文件

 if($filename != "." && $filename != "..")

 {  

 	$filename = iconv("GBK", "UTF-8",$filename);
	$name[]=  $filename;
 

  }

}

?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title></title>
		<link rel="stylesheet" href="index.css" />
		

		
		<script type="text/javascript">
		var r = 0;
		//用于获取返回参数
　　		function GetUrlParam(paraName) {
　　　　var url = document.location.toString(); //得到完整的url
　　　　var arrObj = url.split("?");
　　　　if (arrObj.length > 1) {
　　　　　　var arrPara = arrObj[1].split("&"); //数组类型
　　　　　　var arr;
　　　　　　for (var i = 0; i < arrPara.length; i++) {
　　　　　　　　arr = arrPara[i].split("=");
　　　　　　　　if (arr != null && arr[0] == paraName) {
　　　　　　　　　　return arr[1];
　　　　　　　　}
　　　　　　}
　　　　　　return "";
　　　　}
　　　　else {
　　　　　　return "";
　　　　}
　　}
		r = GetUrlParam('r');
		if(r==2){
			alert("添加成功！");
		}else if(r==1){
			alert("添加失败！");
		}
		
				//表单提交
				function subForm()
				{
					form.action="createdir.php";
					form.submit();
				}
				window.onload = function(){
					var asideTop = document.querySelector("section>aside>.top");
					asideTop.onclick = function(){
					console.log("添加分组！");
				}
				/*遮罩层*/
				var createTeam = document.getElementById("createTeam");
				
				createTeam.onclick = function(){
					var sHeight = document.documentElement.scrollHeight;
					var sWidth = document.documentElement.scrollWidth;
					var oMask = document.createElement("div")
						oMask.id = "mask";
						oMask.style.height = sHeight;
						oMask.style.width = sWidth;
						document.body.appendChild(oMask);
					var creatContent = document.createElement("div");
						creatContent.id = "creatContent";
						oMask.appendChild(creatContent);
					var createTop = document.createElement("div");
						createTop.id = "createTop";
						createTop.className = "top";
						creatContent.appendChild(createTop);
						createTop.innerHTML = "<h2>新建比赛</h2>";
					var createForm = document.createElement("form");
						createForm.id="form";
						creatContent.appendChild(createForm);
						
						
						
					var createInput = document.createElement("div");
						createInput.id = "createInput";
						createInput.className = "input";
						createForm.appendChild(createInput);
						createInput.innerHTML = "&nbsp;&nbsp;&nbsp;&nbsp;比赛名称 &nbsp;&nbsp;<input type='' name='name' id='' value='' />";
					var createButtom = document.createElement("div");
						createButtom.id = "createButtom";
						createButtom.className = "buttom";
						creatContent.appendChild(createButtom);
						createButtom.innerHTML = '<br/><span class="left" id="createYes" onclick="subForm()">确定</span><span class="left" id="createNo">&nbsp;&nbsp;取消</span>';
					var createNo = document.getElementById("createNo");
						createNo.onclick = function(){
							document.body.removeChild(oMask);
						}
				}
				
				
				
				
				
			}
		</script>
	</head>
	<body>
		<header>
			<div class="container">
				<nav>
					<a href="./index.php">竞赛管理平台</a>
				</nav>
			</div>
		</header>
		
		<section class="main">
			<aside>
				<div class="top">
					<h2 id="createGroup">比赛分组</h2>
				</div>
				<div class="list">
					<ul>
						<li class="active">
							<a href="#">默认分组</a>
						</li>
						
					</ul>
				</div>
			</aside>
			<article>
				<div class="top">
					<h2>默认分组</h2>
				</div>
				<div class="content">
					<div class="newPlus">
						<a href="#" id="createTeam">
							<div class="img">
							<img src="plus-circle(3).png"/>
							</div>
							<h3>新建比赛</h3>
						</a>
					</div>
					
					<?php foreach($name as $n):?>
					
					<div class="contentItem1" id='contentItem1'>
						<a href="list.php?name=<?php echo $n ?>">
							<h3><?php echo $n ?></h3>
							<div class="img">
								<img src="./img/xiong.png"/>
							</div>
						</a>
					</div>
					<?php endforeach;?>
					
				</div>
			</article>
		</section>
		<!--
		<div id="mask">
			<div id="creatContent">
				<div class="top" id="createTop">
					<h2>新建工作表分组</h2>
				</div>
				<div class="input" id="createInput">
					分组名称 &nbsp;&nbsp;<input type="" name="" id="" value="" />
				</div>
				<div class="buttom" id="createButtom">
					<span class="left">
						确定
					</span>
					<span class="left">
						&nbsp;&nbsp;取消
					</span>
				</div>
			</div>
		</div>
		-->
	</body>
</html>