<?php
$name = $_GET['name'];


?>



<!DOCTYPE html>
<html lang="en" class="no-js">

    <head>

        <meta charset="utf-8">
        <title>Fullscreen Login</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">

        <!-- CSS -->
        <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=PT+Sans:400,700'>
        <link rel="stylesheet" href="css/reset.css">
        <link rel="stylesheet" href="css/supersized.css">
        <link rel="stylesheet" href="css/style.css">

       

    </head>

    <body>

        <div class="page-container">
            <h1>个人信息</h1>
            <form action="add.php" method="get">
                <input type="text" name="name" class="username" placeholder="请输入姓名">
				<input type="text" name="num" class="username" placeholder="请输入学号">
				<input type="text" name="banji" class="username" placeholder="请输入班级">
				<input type="text" name="qq" class="username" placeholder="请输入QQ">
				<input type="text" name="phone" class="username" placeholder="请输入联系方式">
				<input type="hidden" name="team" value="<?php echo $name;?>" />
                <button type="submit">点我去上传作品</button>
                <div class="error"><span>+</span></div>
            </form>
            
        </div>
        

        <!-- Javascript -->
        <script src="js/jquery-1.8.2.min.js"></script>
        <script src="js/supersized.3.2.7.min.js"></script>
        <script src="js/supersized-init.js"></script>
        <script src="js/scripts.js"></script>

    </body>

</html>

