<?php
/*
**获取当年目录下所有的文件夹名
*/
$handler = opendir('article');
$name = array();

/*其中$filename = readdir($handler)

每次循环时将读取的文件名赋值给$filename，$filename !== false。

一定要用!==，因为如果某个文件名如果叫'0′，或某些被系统认为是代表false，用!=就会停止循环

*/

while( ($filename = readdir($handler)) !== false ) 
{

 //略过linux目录的名字为'.'和‘..'的文件

 if($filename != "." && $filename != "..")

 {  

 	$filename = iconv("GBK", "UTF-8",$filename);
	$name[]=  $filename;
 

  }

}

?>

<!doctype html>
<html>

	<head>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="xuanze.css" />
		<link rel="stylesheet" href="http://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
		<script src="http://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>
		<script src="http://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
	</head>

	<body>
		<div class="all">
			<div class="top">
				
				<div class="text">
					竞赛信息
				</div>
				
			</div>
			<div class="ttop">
				
			</div>
			<div class="content">
				<!-- 轮播 -->
				<div id="myCarousel" class="carousel slide">
					<!-- 轮播（Carousel）指标 -->
					<ol class="carousel-indicators">
						<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
						<li data-target="#myCarousel" data-slide-to="1"></li>
						<li data-target="#myCarousel" data-slide-to="2"></li>
					</ol>
					<!-- 轮播（Carousel）项目 -->
					<div class="carousel-inner">
						<div class="item active">
							<a href="content.html"><img src="img/yiban.jpg" alt="First slide"></a>
						</div>
						<div class="item">
							<a href="content2.html"><img src="img/timg.gif" alt="Second slide"></a>
						</div>
						<div class="item">
							<a href="content.html"><img src="img/yiban.gif" alt="Third slide"></a>
						</div>
					</div>
					<!-- 轮播（Carousel）导航 -->
					<a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
						<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
						<span class="sr-only">Previous</span>
					</a>
					<a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
						<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
						<span class="sr-only">Next</span>
					</a>
				</div>
				<div class="listContent">
					<div class="container-fluid">
						<div class="row-fluid">
							<?php foreach ($name as $n): ?>
							<div class="span12">
								<ul class="thumbnails">
									<li class="span4">
										<div class="thumbnail">
											<img alt="300x200" src="img/yiban2.jpg" />
											<div class="caption">
												<h3>
													<?php echo $n ?>
												</h3>
												<p class="pCenter">
													<a class="btn btn-primary" href="xinxi.php?name=<?php echo $n; ?>">参加</a>
												</p>
											</div>
										</div>
									</li>
								</ul>
							</div>
							<?php endforeach ?>
							
						</div>
					</div>
				</div>
			</div>

			
		</div>
	</body>

</html>