<?php
$name = $_GET['name'];
$num = $_GET['num'];
$banji = $_GET['banji'];
$qq = $_GET['qq'];
$phone = $_GET['phone'];
$team = $_GET['team'];
/*
@mysql_connect('localhost','root','');
	mysql_query('set names utf8');
	mysql_select_db('yiban'); //数据库名


	$sql="insert into {$team} (姓名,学号,QQ,联系方式,班级) values('{$name}','{$num}','{$qq}','{$phone}','{$banji}')";
	//var_dump ($sql);
	$res = mysql_query($sql);

*/

?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<link rel="stylesheet" href="add.css" />

		<link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">  
		<script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>
		<script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>

		<title></title>
		<script type="text/javascript"> 
			function openBrowse(){ 
　　				var ie=navigator.appName=="Microsoft Internet Explorer" ? true : false; 
　　				if(ie){ 
　　　　				document.getElementById("file").click(); 
　　				}else{
　　　　				var a=document.createEvent("MouseEvents");//FF的处理 
　　　　				a.initEvent("click", true, true);  
　　　　				document.getElementById("file").dispatchEvent(a); 
　　				}
					
					
					
			} 
			window.onload = function() {
				var fileInput = document.getElementById('file');
				fileInput.addEventListener('change', function() {
				if(!fileInput.value) {
			
					return;
				}
				
					
					uploadForm.submit();
			})
			}
			
			
	
		</script>
	</head>
	<body>
		<!--添加文件-->
		<div id="add" >
			<div class="top">
			</div>
			<div class="file">
				
				<form action="chuli.php" method="post" target="" id="uploadForm" enctype="multipart/form-data">
				
				<div class="formTop">
				</div>
					<input id="file" type="file" name="file" multiple="multiple"/>
					<input type="hidden" name="name" value="<?php echo $name;?>">
				<input type="hidden" name="num" value="<?php echo $num;?>">
				<input type="hidden" name="banji" value="<?php echo $banji;?>">
				<input type="hidden" name="qq" value="<?php echo $qq;?>">
				<input type="hidden" name="phone" value="<?php echo $phone;?>">
				<input type="hidden" name="team" value="<?php echo $team;?>" />
					<div class="upload"  onclick="javascript:openBrowse();">
						<div class="img">
							<img src="file.png"/>
							<h3 id="h3">点击上传文件</h3>
						</div>
					</div>
				</form>
			</div>
		</div>
		
		
		
        </script>
	</body>
</html>
