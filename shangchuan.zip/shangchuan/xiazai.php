<?php
$time = time();
$name = $_GET['name'];
$name = iconv("UTF-8", "GBK",$name);
$dir = 'article/'.$name."/";

/*
**获取当年目录下所有的文件夹名
*/
$handler = opendir($dir);

/*article/s/*/
$datalist = array();

/*其中$filename = readdir($handler)

每次循环时将读取的文件名赋值给$filename，$filename !== false。

一定要用!==，因为如果某个文件名如果叫'0′，或某些被系统认为是代表false，用!=就会停止循环

*/

while( ($filename = readdir($handler)) !== false ) 
{

 //略过linux目录的名字为'.'和‘..'的文件

 if($filename != "." && $filename != "..")

 {  

 	$filename = iconv("GBK", "UTF-8",$filename);
	$datalist[]=  "./".$dir.$filename;
 

  }

}


$filename = "./zip/".$time.".zip";

if(!file_exists($filename)){
 $zip = new ZipArchive();
 if ($zip->open($filename, ZipArchive::CREATE)==TRUE) {
  foreach( $datalist as $val){
   if(file_exists($val)){
    $zip->addFile( $val, basename($val));
   }
  }
  $zip->close();
 }
}
if(!file_exists($filename)){
 exit("无法找到文件");
}
header("Cache-Control: public");
header("Content-Description: File Transfer");
header('Content-disposition: attachment; filename='.basename($filename)); //文件名
header("Content-Type: application/zip"); //zip格式的
header("Content-Transfer-Encoding: binary"); //告诉浏览器，这是二进制文件
header('Content-Length: '. filesize($filename)); //告诉浏览器，文件大小*/
header("Location:".$filename); 

