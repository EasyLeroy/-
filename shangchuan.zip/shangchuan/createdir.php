<?php
	//获取提交的比赛名，用于创建文件夹
	$name = $_GET['name'];
	/*iconv方法是为了防止中文乱码，保证可以创建识别中文目录，不用iconv方法格式的话，将无法创建中文目录*/
	$dir = iconv("UTF-8", "GBK",$name);
	$dir = "article/" . $dir;
	/**mkdir方法的第一个参数是要创建的目录路径，
	 **第二个参数是指创建目录的权限，在windows系统下
	 **该参数会被忽略，第三个参数是指是否创建多级目录，
	 **默认为false
	**/
    if (!file_exists($dir)){
        mkdir ($dir,0777,true);

/*创建数据库表*/

@mysql_connect('localhost','root','');
mysql_query("set names utf8");
mysql_select_db('yiban');
$sql = "CREATE TABLE `" . $name . "`";
$sql = $sql . <<<SQL
(
`ID`  int NOT NULL AUTO_INCREMENT ,
`姓名`  varchar(255) NOT NULL ,
`学号`  varchar(255) NOT NULL ,
`QQ`  varchar(255) NOT NULL ,
`联系方式`  varchar(255) NOT NULL ,
`班级`  varchar(255) NOT NULL ,
PRIMARY KEY (`id`)
)  CHARSET=utf8;
SQL;

mysql_query($sql);



        //echo '创建文件夹成功';
		header('Location:index.php?r=2');
     } else {
		 header('Location:index.php?r=1');
		//echo '需创建的文件夹已经存在';
     }


	 