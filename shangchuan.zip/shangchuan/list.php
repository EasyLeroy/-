<?php
	
	$name = $_GET['name'];
	@mysql_connect('localhost','root','');
	mysql_query('set names utf8');
	mysql_select_db('yiban'); //数据库名
	$sql="select *from {$name}"; //sql语句
	$res = mysql_query($sql);
	$rows = array();
	while($row=mysql_fetch_assoc($res)){
		$rows[] = $row;
	}
	//var_dump($rows);
	
	/*得到表头*/
	$tableName = array();
	foreach($rows as $value){
	foreach ($value as $k => $v){
		$tableName[] = $k;
	}
	break;
	}
	//var_dump($tableName);
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>
	<script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="list.css" />
	<title></title>
	<script type="text/javascript">
		window.onload = function(){
			var tableTop = document.getElementById("re");
				tableTop.onclick = function(){
					window.location.assign("./index.php");
				}
			var down = document.getElementById("down");
				down.onclick = function(){
					window.location.assign("./xiazai.php?name=<?php echo $name; ?>");
				}
		}
	</script>
</head>
<body>
	<div class="tableTop" id="tableTop">
		<img id="re" src="return.png"/>
		<h1><?php echo $name;?></h1>
		<div class="down" id="down">
			<img src="img/down.png"/>&nbsp;&nbsp;&nbsp;下载
		</div>
		
		
	</div>
	<table class="table table-striped table-hover">
		<thead>
			<tr>
				<?php foreach($tableName as $value){
					echo "<th>" . $value . "</th>";
					
					}
				?>
				
			</tr>
		</thead>
		<tbody>
		<?php foreach($rows as $value): ?>
			<tr>
				<?php foreach($value as $v){
				echo "<td>" . $v . "</td>";
				}
				?>
			</tr>
		<?php endforeach;?>
		</tbody>
	</table>
</body>
</html>
